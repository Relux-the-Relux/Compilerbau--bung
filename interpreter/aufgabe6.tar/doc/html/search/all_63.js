var searchData=
[
  ['cap',['cap',['../stack_8h.html#af62eae1620714e1ec1f543554287b83c',1,'stack_hdr_t::cap()'],['../syntree_8h.html#a14a829254b245b89c3af75d1e2587629',1,'syntree_t::cap()']]]
];
