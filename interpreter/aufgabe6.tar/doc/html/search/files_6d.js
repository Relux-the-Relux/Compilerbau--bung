var searchData=
[
  ['minako_2ec',['minako.c',['../minako_8c.html',1,'']]]
];
