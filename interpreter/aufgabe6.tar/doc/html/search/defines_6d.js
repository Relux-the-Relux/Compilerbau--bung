var searchData=
[
  ['minako_5fstack_5fsize',['MINAKO_STACK_SIZE',['../minako_8c.html#ad0d1d843e20e4902393fe084f084b456',1,'minako.c']]]
];
